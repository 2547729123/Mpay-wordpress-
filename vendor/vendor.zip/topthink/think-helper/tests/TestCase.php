<?php

namespace Tests;

use PHPUnit\Framework\TestCase as BaseTestCase;

/**
 * Class TestCase
 * @author Tongle Xu <xutongle@gmail.com>
 */
class TestCase extends BaseTestCase
{
}
