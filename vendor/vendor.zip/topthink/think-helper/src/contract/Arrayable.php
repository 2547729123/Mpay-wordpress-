<?php

namespace think\contract;

interface Arrayable
{
    public function toArray(): array;
}
