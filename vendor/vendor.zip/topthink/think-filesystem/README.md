# think-filesystem for ThinkPHP6.1

## 安装

> composer require topthink/think-filesystem
